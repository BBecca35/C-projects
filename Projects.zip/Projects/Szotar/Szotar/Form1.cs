namespace Szotar
{
    public partial class Form1 : Form
    {
        Dictionary<string, string> szotar;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            szotar = new Dictionary<string, string>();
            szotar.Add("Apple", "Alma");
            szotar.Add("Mouse", "Eg�r");
            szotar.Add("Keyboard", "Billenty�zet");
            szotar.Add("Phone", "Telefon");
            szotar.Add("Window", "Ablak");
            listBox1.Items.AddRange(szotar.Keys.ToArray());
            listBox2.Items.AddRange(szotar.Values.ToArray());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string keresettErtek = textBox1.Text;
            string megtalaltKulcs = null;
            foreach (var par in szotar)
            {
                if (par.Value == keresettErtek)
                {
                    megtalaltKulcs = par.Key;
                    break;
                }
            }
            if (megtalaltKulcs != null)
            {
                label3.Text = "A keresett sz�: " + megtalaltKulcs;
            }
            else {
                label3.Text = "A keresett sz� nem tal�lhat�!";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ertek = textBox2.Text;
            if (szotar.ContainsKey(textBox2.Text))
            {
                label3.Text = "A keresett sz�: " + szotar[textBox2.Text];
            }
            else
            {
                label3.Text = "A keresett sz� nem tal�lhat�!";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = !string.IsNullOrWhiteSpace(textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            button2.Enabled = !string.IsNullOrWhiteSpace(textBox2.Text);
        }
    }
}
