using System.Windows.Forms;

namespace Szamlalok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
            numericUpDown1.Value = lepesSzamlalo.Actual;
            numericUpDown1.Maximum = lepesSzamlalo.K�sz�b;
            int mennyivel = (int)numericUpDown1.Increment;
            lepesSzamlalo.N�vel(mennyivel);
        }
    }
}
