namespace Választás
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radiogombok_kiertekelese(object sender, EventArgs e)
        {
            String? nem = null;
            if (radioButton1.Checked) nem = "Férfi";
            if (radioButton2.Checked) nem = "Nő";
            if (radioButton3.Checked) nem = "Egyéb";
            String? fizetesi_mod = null;
            if (radioButton4.Checked) fizetesi_mod = "PayPal";
            if (radioButton5.Checked) fizetesi_mod = "Bankkártya";
            if (radioButton6.Checked) fizetesi_mod = "Utánvét";
            if (nem != null && fizetesi_mod != null) {
                label1.Text = "A választott elem: nem = " + nem + ", fizetési mód = " + fizetesi_mod;
            }    
        }
    }
}
