namespace ListaDobozok
{
    //nem tartalmazhat 

    public partial class Form1 : Form
    {
        List<string> csoport;
        Dictionary<string, string> szotar;
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            label2.Text = "A ki�lasztott elem sorsz�ma: " + listBox1.SelectedIndex;
            label3.Text = "A ki�lasztott elem: " + listBox1.SelectedItem;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            csoport = new List<string>();
            csoport.Add("Zsanett");
            csoport.Add("Adam");
            csoport.Add("Istvan");
            //csoport.Sort();
            listBox1.Items.AddRange(csoport.ToArray());
            //listBox1.Sorted = true;

            //Lehetne b�v�teni sz�k�teni
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox1.Text);
            label5.Text = "A hozz�ad�s megt�rt�nt";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Contains(textBox2.Text))
            {
                listBox1.Items.Remove(textBox2.Text);
                label5.Text = "A t�rl�s megt�rt�nt"; 
            }
            else
            {
                label5.Text = "Az adott n�v nem tal�lhat� a csoportban!";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = !string.IsNullOrWhiteSpace(textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            button2.Enabled = !string.IsNullOrWhiteSpace(textBox2.Text);
        }
    }
}
