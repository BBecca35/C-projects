﻿// See https://aka.ms/new-console-template for more information
using static System.Net.Mime.MediaTypeNames;

namespace Datum
{
    internal static class Program
    {

        static void Main()
        {
            //eltelt napok szama
            DateTime startDate = new DateTime(2024, 1, 1);
            DateTime today = DateTime.Today;

            TimeSpan difference = today - startDate;
            int daysElapsed = difference.Days;

            Console.WriteLine("Eltelt napok: " + daysElapsed);

            //
        }
    }
}
