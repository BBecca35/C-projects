namespace Szamlalok
{
    class Szamlalo {
        private int actual = 0;
        private int k�sz�b;

        public Szamlalo(int actual, int k�sz�b)
        {
            this.actual = actual;
            this.k�sz�b = k�sz�b;
        }

        public int Actual
        {
            get { return actual; }
            set { actual = value; }
        }

        // Getter �s Setter a 'k�sz�b' tulajdons�ghoz
        public int K�sz�b
        {
            get { return k�sz�b; }
            set { k�sz�b = value; }
        }

        public event EventHandler KuszobEsemeny;

        public void KuszobElerese(EventArgs e)
        {
            EventHandler kezelo = KuszobEsemeny;
            //A k�ld� object mi vagyunk, a kapott esem�nyt tov�bb�tjuk.
            if (kezelo != null)
            {
                kezelo(this, e);

            }
        }

        public void N�vel(int mennyivel)
        {
            actual += mennyivel;
            if (actual >= k�sz�b && actual - mennyivel == k�sz�b)
            {
                //Nincs t�bbletinform�ci� a k�ld�skor, ez�rt �res.
                //Az eventargs most m�r tartalmazza a k�sz�b el�r�s�nek ir�ny�t, ami t�bbletinform�ci�nak sz�m�t.
                KuszobElerese(EventArgs.Empty);
            }
        }

    }
    internal static class Program
    {
       
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}