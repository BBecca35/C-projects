namespace Grafika
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int x, y;
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Pen toll = new Pen(Color.Blue, 2);
            Graphics g = e.Graphics;
            g.DrawRectangle(toll, x, y, 100, 100);
        }

        
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
           x = e.X; y = e.Y;
            Refresh();
        }
    }
}
