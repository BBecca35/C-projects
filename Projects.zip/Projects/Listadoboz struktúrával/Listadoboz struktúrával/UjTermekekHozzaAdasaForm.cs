﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Listadoboz_struktúrával
{
    public partial class UjTermekekHozzaAdasaForm : Form
    {
        public Termek UjTermek { get; private set; }
        public UjTermekekHozzaAdasaForm()
        {
            InitializeComponent();
            comboBox1.DataSource = Enum.GetValues(typeof(Kategoria));
        }

        private void UjTermekekHozzaAdasaForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int azonosito = int.Parse(textBox1.Text);
                string nev = textBox2.Text;
                Kategoria kategoria = (Kategoria)comboBox1.SelectedItem;
                double egysegar = double.Parse(textBox3.Text);
                int raktarKeszlet = int.Parse(textBox4.Text);

                UjTermek = new Termek(azonosito, nev, kategoria, egysegar, raktarKeszlet);
                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adatok mentésekor: " + ex.Message);
            }
        }
    }
}
