﻿using System;

internal class Program
{
    private static void Main(string[] args){
        //code snipet -> rövidítések
        int n = 0;
        Console.WriteLine("Hello, World!");
        for (int i = 0; i < 100; i++) {
            n =+ i;
            
            
        }
        Console.WriteLine("Összeg: "+n);
    }
}