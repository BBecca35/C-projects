﻿namespace Egyeztető
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            checkBox7 = new CheckBox();
            checkBox8 = new CheckBox();
            checkBox9 = new CheckBox();
            checkBox10 = new CheckBox();
            label1 = new Label();
            label2 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(171, 69);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(66, 24);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "hétfő";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(171, 99);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(64, 24);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "kedd";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(171, 129);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(74, 24);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "szerda";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(171, 159);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(92, 24);
            checkBox4.TabIndex = 3;
            checkBox4.Text = "csütörtök";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(171, 189);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(76, 24);
            checkBox5.TabIndex = 4;
            checkBox5.Text = "péntek";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Location = new Point(480, 189);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(76, 24);
            checkBox6.TabIndex = 9;
            checkBox6.Text = "péntek";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Location = new Point(480, 159);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new Size(92, 24);
            checkBox7.TabIndex = 8;
            checkBox7.Text = "csütörtök";
            checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            checkBox8.AutoSize = true;
            checkBox8.Location = new Point(480, 129);
            checkBox8.Name = "checkBox8";
            checkBox8.Size = new Size(74, 24);
            checkBox8.TabIndex = 7;
            checkBox8.Text = "szerda";
            checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            checkBox9.AutoSize = true;
            checkBox9.Location = new Point(480, 99);
            checkBox9.Name = "checkBox9";
            checkBox9.Size = new Size(64, 24);
            checkBox9.TabIndex = 6;
            checkBox9.Text = "kedd";
            checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            checkBox10.AutoSize = true;
            checkBox10.Location = new Point(480, 69);
            checkBox10.Name = "checkBox10";
            checkBox10.Size = new Size(66, 24);
            checkBox10.TabIndex = 5;
            checkBox10.Text = "hétfő";
            checkBox10.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(181, 34);
            label1.Name = "label1";
            label1.Size = new Size(79, 20);
            label1.TabIndex = 10;
            label1.Text = "Dolgozó 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(493, 34);
            label2.Name = "label2";
            label2.Size = new Size(79, 20);
            label2.TabIndex = 11;
            label2.Text = "Dolgozó 2";
            label2.Click += label2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(328, 257);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 12;
            button1.Text = "Egyeztetés";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(770, 320);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(checkBox6);
            Controls.Add(checkBox7);
            Controls.Add(checkBox8);
            Controls.Add(checkBox9);
            Controls.Add(checkBox10);
            Controls.Add(checkBox5);
            Controls.Add(checkBox4);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Egyeztető";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private CheckBox checkBox7;
        private CheckBox checkBox8;
        private CheckBox checkBox9;
        private CheckBox checkBox10;
        private Label label1;
        private Label label2;
        private Button button1;
    }
}
