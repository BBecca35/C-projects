﻿// See https://aka.ms/new-console-template for more information

enum IranyTipus
{
    fel,
    le
};

//Sajat felsorolas típus az irany jelölésére
class KuszobIranyArgs : EventArgs {

    public IranyTipus irany;

    public KuszobIranyArgs(IranyTipus irany)
    {
        this.irany = irany;
    }
}
class Szamlalo {
    //Adattagok:
    private int actual = 0;
    private int küszöb;

    //Konstruktorok (ctrl + .) in intelliJ (Alt + fn + insert vagy Alt + insert)
    public Szamlalo(int actual, int küszöb)
    {
        this.actual = actual;
        this.küszöb = küszöb;
    }

    public void Növel(int mennyivel) {
        actual += mennyivel;
        if (actual >= küszöb) {

            KuszobIranyArgs iranyArgs = new KuszobIranyArgs(IranyTipus.fel);
            //Nincs többletinformáció a küldéskor, ezért üres.
            //Az eventargs most már tartalmazza a küszöb elérésének irányát, ami többletinformációnak számít.
            KuszobElerese(EventArgs.Empty);
        }
    }

    public void Csökkent(int mennyivel)
    {
        actual -= mennyivel;
        if (actual <= küszöb)
        {
            KuszobIranyArgs iranyArgs = new KuszobIranyArgs(IranyTipus.le);
            //Nincs többletinformáció a küldéskor, ezért üres.
            KuszobElerese(EventArgs.Empty);
        }
    }
    //Saját esemény
    public event EventHandler KuszobEsemeny;

    //Készítek egy EventHandler típusú metódust, ami a küszöbeseményre reagál.
    //Esemény kezelő példányosítás
    //Na kérem szépen számláló
    public void KuszobElerese(EventArgs e) {
        EventHandler kezelo = KuszobEsemeny;
        //A küldő object mi vagyunk, a kapott eseményt továbbítjuk.
        if (kezelo != null) {kezelo (this, e);
        
        }
    }

}
internal class Events {
    private static void Main(string[] args) {
        //Szükséges napi lépések száma = 7500
        //Példányosítom a Szamlalo osztályt.
        //Feliratkozás az eseményre.
        Szamlalo lepesszamlalo = new Szamlalo(0, 7500);
        lepesszamlalo.KuszobEsemeny += Lepesszamlalo_KuszobEsemeny;
        lepesszamlalo.Növel(1000);
        Console.WriteLine("Ezerrel növeltem a lépésszámot.");
        lepesszamlalo.Növel(5000);
        lepesszamlalo.Növel(2500);


        Szamlalo tomegSzamlalo = new Szamlalo(83, 78);
        tomegSzamlalo.KuszobEsemeny += TomegSzamlalo_KuszobEsemeny;
        Console.WriteLine("Csökkentem a tömegemet 3 Kg-mal!");
        
        tomegSzamlalo.Csökkent(3);

    }

    private static void TomegSzamlalo_KuszobEsemeny(object? sender, EventArgs e)
    {
        // A kapott EventArgs valójában az általam megírt típusú,
        // így benne vam az irány információja is
        if (((KuszobIranyArgs)e).irany == IranyTipus.fel)
        {
            Console.WriteLine("Felfelé");
        }
        else {
            Console.WriteLine("Lefelé");
        }
            
        
    }

    private static void Lepesszamlalo_KuszobEsemeny(object? sender, EventArgs e)
    {
        Console.WriteLine("Elértük a napi lépésszám célját!");
    }
}

/*
 //Saját felsorolástípus az irány jelölésére:
enum IrányTípus { fel, le};

//Saját EventArgs osztály készítése, hogy értesüljünk a küszöbátlépés irányáról
class KüszöbIrányArgs : EventArgs
{
    public IrányTípus irány;
    //Konstruktor
    public KüszöbIrányArgs(IrányTípus irány)
    {
        this.irány = irány;
    }
}

class Számláló
{
    //Adattagok:
    private int aktuális = 0;
    private int küszöb;

    //Konstruktor
    public Számláló(int aktuális, int küszöb)
    {
        this.aktuális = aktuális;
        this.küszöb = küszöb;
    }

    //Aktuális érték növelése
    public void Növel(int mennyivel)
    {
        aktuális += mennyivel;
        //Ha elértük a növeléssel a küszöböt, bekövetkezik az esemény
        //Az eventargs tartalmazza az átlépés irányát (fel)
        if (aktuális >= küszöb)
        {
            KüszöbIrányArgs irányArgs = new KüszöbIrányArgs(IrányTípus.fel);
            KüszöbElérése(irányArgs);
        }
    }

    //Aktuális érték csökkenése
    public void Csökkent(int mennyivel)
    {
        aktuális -= mennyivel;
        //Ha elértük a csökkentéssel a küszöböt, bekövetkezik az esemény
        //Az eventargs most lefelé mutat
        if (aktuális <= küszöb) {
            KüszöbIrányArgs irányArgs = new KüszöbIrányArgs(IrányTípus.le);
            KüszöbElérése(irányArgs);
        }
    }

    //Saját esemény készítése a küszöb elérésekor
    public event EventHandler KüszöbEsemény;

    //Készítek egy EventHandler típusú metódust, ami a küszöbeseményre reagál:
    //Ez tulajdonképpen egy eseménykezelő példányosítás
    public void KüszöbElérése(EventArgs e) {
        EventHandler kezelő = KüszöbEsemény;
        //Ha az eseménykezelő létrejött, akkor meghívjuk:
        //A küldő objektum mi vagyunk, a kapott eseményt továbbítjuk
        if (kezelő != null) kezelő(this, e);
    }
}

internal class Program
{
    private static void Main(string[] args)
    {
        //Példányosítom a számlálót.
        //A szükséges napi lépések száma: 7500
        Számláló lépésSzámláló = new Számláló(0, 7500);

        //Feliratkozás az eseményre:
        lépésSzámláló.KüszöbEsemény += LépésSzámláló_KüszöbEsemény;
        lépésSzámláló.Növel(1000);
        Console.WriteLine("Ezerrel növeltem a lépésszámot");
        lépésSzámláló.Növel(5000);
        Console.WriteLine("Ötezerrel növeltem a lépésszámot");
        lépésSzámláló.Növel(2000);
        Console.WriteLine("Kétezerrel növeltem a lépésszámot");

        Számláló tömegSzámláló = new Számláló(83, 78);
        //Feliratkozás az eseményre:
        tömegSzámláló.KüszöbEsemény += TömegSzámláló_KüszöbEsemény;
        tömegSzámláló.Csökkent(3);
        Console.WriteLine("Csökkent a tömegem 3 kg-al");
        tömegSzámláló.Csökkent(2);
        Console.WriteLine("Csökkent a tömegem 2 kg-al");

    }

    private static void TömegSzámláló_KüszöbEsemény(object? sender, EventArgs e)
    {
        Console.Write("Elértük a kívánt tömeget,");
        //A kapott EventArgs valójában az általam megírt típusú,
        //így benne van az irány információja is
        if (((KüszöbIrányArgs)e).irány == IrányTípus.fel)
            Console.WriteLine("felfelé!");
        else Console.WriteLine("lefelé!");
    }

    private static void LépésSzámláló_KüszöbEsemény(object? sender, EventArgs e)
    {
        Console.WriteLine("Elértük a napi lépésszám célját!");
    }
}
 */
