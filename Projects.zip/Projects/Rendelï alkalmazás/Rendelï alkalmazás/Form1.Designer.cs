﻿namespace Rendelő_alkalmazás
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            radioButton8 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton6 = new RadioButton();
            groupBox2 = new GroupBox();
            radioButton11 = new RadioButton();
            radioButton10 = new RadioButton();
            radioButton9 = new RadioButton();
            groupBox3 = new GroupBox();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            groupBox4 = new GroupBox();
            radioButton5 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButton8);
            groupBox1.Controls.Add(radioButton7);
            groupBox1.Controls.Add(radioButton6);
            groupBox1.Location = new Point(40, 75);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(178, 125);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Termék színe";
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.Location = new Point(6, 86);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(131, 24);
            radioButton8.TabIndex = 3;
            radioButton8.TabStop = true;
            radioButton8.Text = "Fehér (6.500 Ft)";
            radioButton8.UseVisualStyleBackColor = true;
            radioButton8.CheckedChanged += radioGomb_kivalasztas;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.Location = new Point(6, 57);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(126, 24);
            radioButton7.TabIndex = 2;
            radioButton7.TabStop = true;
            radioButton7.Text = "Zöld (9.000 Ft)";
            radioButton7.UseVisualStyleBackColor = true;
            radioButton7.CheckedChanged += radioGomb_kivalasztas;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.Location = new Point(6, 27);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(138, 24);
            radioButton6.TabIndex = 1;
            radioButton6.TabStop = true;
            radioButton6.Text = "Fekete (7.000 Ft)";
            radioButton6.UseVisualStyleBackColor = true;
            radioButton6.CheckedChanged += radioGomb_kivalasztas;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButton11);
            groupBox2.Controls.Add(radioButton10);
            groupBox2.Controls.Add(radioButton9);
            groupBox2.Location = new Point(257, 75);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(148, 125);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Felirat színe";
            // 
            // radioButton11
            // 
            radioButton11.AutoSize = true;
            radioButton11.Location = new Point(6, 87);
            radioButton11.Name = "radioButton11";
            radioButton11.Size = new Size(66, 24);
            radioButton11.TabIndex = 6;
            radioButton11.TabStop = true;
            radioButton11.Text = "Fehér";
            radioButton11.UseVisualStyleBackColor = true;
            radioButton11.CheckedChanged += radioGomb_kivalasztas;
            // 
            // radioButton10
            // 
            radioButton10.AutoSize = true;
            radioButton10.Location = new Point(6, 57);
            radioButton10.Name = "radioButton10";
            radioButton10.Size = new Size(62, 24);
            radioButton10.TabIndex = 5;
            radioButton10.TabStop = true;
            radioButton10.Text = "Piros";
            radioButton10.UseVisualStyleBackColor = true;
            radioButton10.CheckedChanged += radioGomb_kivalasztas;
            // 
            // radioButton9
            // 
            radioButton9.AutoSize = true;
            radioButton9.Location = new Point(6, 27);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(138, 24);
            radioButton9.TabIndex = 4;
            radioButton9.TabStop = true;
            radioButton9.Text = "Fekete (2.000 Ft)";
            radioButton9.UseVisualStyleBackColor = true;
            radioButton9.CheckedChanged += radioGomb_kivalasztas;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(radioButton2);
            groupBox3.Controls.Add(radioButton1);
            groupBox3.Location = new Point(40, 221);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(178, 125);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Nem";
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(15, 56);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(50, 24);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Nő";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioGomb_kivalasztas;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(15, 26);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(59, 24);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Férfi";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioGomb_kivalasztas;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(radioButton5);
            groupBox4.Controls.Add(radioButton4);
            groupBox4.Controls.Add(radioButton3);
            groupBox4.Location = new Point(257, 221);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(148, 125);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Fizetési mód";
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Location = new Point(18, 86);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(81, 24);
            radioButton5.TabIndex = 4;
            radioButton5.TabStop = true;
            radioButton5.Text = "Utánvét";
            radioButton5.UseVisualStyleBackColor = true;
            radioButton5.CheckedChanged += radioGomb_kivalasztas;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(18, 56);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(102, 24);
            radioButton4.TabIndex = 3;
            radioButton4.TabStop = true;
            radioButton4.Text = "Bankkártya";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioGomb_kivalasztas;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(18, 26);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(71, 24);
            radioButton3.TabIndex = 2;
            radioButton3.TabStop = true;
            radioButton3.Text = "PayPal";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioGomb_kivalasztas;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(40, 386);
            label1.Name = "label1";
            label1.Size = new Size(251, 28);
            label1.TabIndex = 4;
            label1.Text = "Rendelt póló tulajdonságai:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F);
            label2.Location = new Point(349, 9);
            label2.Name = "label2";
            label2.Size = new Size(265, 32);
            label2.TabIndex = 5;
            label2.Text = "Three Days Grace Pólók";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 7F);
            label3.Location = new Point(620, 501);
            label3.Name = "label3";
            label3.Size = new Size(371, 15);
            label3.TabIndex = 7;
            label3.Text = "\"Pólók, Pulcsik, Bögrék, Genyók! Minden a leírásban!\" by Csenki Parik";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(40, 452);
            label4.Name = "label4";
            label4.Size = new Size(78, 28);
            label4.TabIndex = 8;
            label4.Text = "Összeg:";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.paypal2;
            pictureBox1.Location = new Point(620, 84);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(282, 262);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1003, 525);
            Controls.Add(pictureBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Rendelés";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private Label label1;
        private Label label2;
        private RadioButton radioButton8;
        private RadioButton radioButton7;
        private RadioButton radioButton6;
        private RadioButton radioButton10;
        private RadioButton radioButton9;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private RadioButton radioButton5;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private RadioButton radioButton11;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox1;
    }
}
