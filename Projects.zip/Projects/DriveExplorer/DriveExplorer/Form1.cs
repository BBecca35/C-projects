namespace DriveExplorer
{
    public partial class Form1 : Form
    {
        private string[] subjects;
        private string[] predicates;
        private string[] objects;
        public Form1()
        {
            InitializeComponent();
            LoadDrives();
            LoadWordsFromFile();
        }

        private void LoadDrives()
        {
            var drives = DriveInfo.GetDrives().Where(d => d.IsReady).ToList();
            comboBox1.DataSource = drives;
            comboBox1.DisplayMember = "Name";
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            File.WriteAllLines("words.txt", new[]
{
                string.Join(",", subjects),
                string.Join(",", predicates),
                string.Join(",", objects)
            });
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            var selectedItem = listBox1.SelectedItem.ToString();
            if (selectedItem.StartsWith("[Folder]"))
            {
                var folderName = selectedItem.Substring(9);
                var selectedDrive = (DriveInfo)comboBox1.SelectedItem;
                var directory = new DirectoryInfo(Path.Combine(selectedDrive.RootDirectory.FullName, folderName));
                LoadDirectoryContents(directory);
            }
            else
            {
                DisplayFileContent(selectedItem);
            }

        }

        private void LoadDirectoryContents(DirectoryInfo directory)
        {
            listBox1.Items.Clear();
            foreach (var dir in directory.GetDirectories())
            {
                listBox1.Items.Add($"[Folder] {dir.Name}");
            }

            foreach (var file in directory.GetFiles("*.txt"))
            {
                listBox1.Items.Add(file.Name);
            }
        }

        private void DisplayFileContent(string fileName)
        {
            var selectedDrive = (DriveInfo)comboBox1.SelectedItem;
            var filePath = Path.Combine(selectedDrive.RootDirectory.FullName, fileName);
            using (var reader = new StreamReader(filePath))
            {
                textBox1.Text = reader.ReadToEnd();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedDrive = (DriveInfo)comboBox1.SelectedItem;
            LoadRootDirectory(selectedDrive);

        }

        private void LoadRootDirectory(DriveInfo drive)
        {
            listBox1.Items.Clear();
            var directories = drive.RootDirectory.GetDirectories();
            foreach (var dir in directories)
            {
                listBox1.Items.Add($"[Folder] {dir.Name}");
            }

            var files = drive.RootDirectory.GetFiles("*.txt");
            foreach (var file in files)
            {
                listBox1.Items.Add(file.Name);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var random = new Random();
            var subject = subjects[random.Next(subjects.Length)];
            var predicate = predicates[random.Next(predicates.Length)];
            var obj = objects[random.Next(objects.Length)];
            textBox1.Text = $"{subject} {predicate} {obj}.";
        }

        private void LoadWordsFromFile()
        {
            // Load words from a predefined file
            if (File.Exists("words.txt"))
            {
                var lines = File.ReadAllLines("words.txt");
                subjects = lines[0].Split(',');
                predicates = lines[1].Split(',');
                objects = lines[2].Split(',');
            }
        }
    }
}
