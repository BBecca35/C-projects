using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Teszt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void gomb_Click(object sender, EventArgs e)
        {
            label1.Visible = !label1.Visible;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}
