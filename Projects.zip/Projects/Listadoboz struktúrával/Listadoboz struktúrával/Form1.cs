using System.Windows.Forms;

namespace Listadoboz_struktúrával
{

    public enum Kategoria
    {
        Elelmiszer,
        Ital,
        Vegyi,
        Papir,
        Műszaki
    }

    public struct Termek
    {
        public int Azonosito { get; set; }
        public string Nev { get; set; }
        public Kategoria Kategoria { get; set; }
        public double Egysegar { get; set; }
        public int RaktarKeszlet { get; set; }

        public Termek(int azonosito, string nev, Kategoria kategoria, double egysegar, int raktarKeszlet)
        {
            Azonosito = azonosito;
            Nev = nev;
            Kategoria = kategoria;
            Egysegar = egysegar;
            RaktarKeszlet = raktarKeszlet;
        }


        public override string ToString()
        {
            return Nev;
        }
    }

    public partial class Form1 : Form
    {
        private List<Termek> termekLista;
        public Form1()
        {
            InitializeComponent();
            termekLista = new List<Termek>
        {
            new Termek(1, "Tej", Kategoria.Elelmiszer, 250, 50),
            new Termek(2, "Kenyér", Kategoria.Elelmiszer, 300, 30),
            new Termek(3, "Víz", Kategoria.Ital, 100, 200),
            new Termek(4, "Narancslé", Kategoria.Ital, 400, 80),
            new Termek(5, "Mosószer", Kategoria.Vegyi, 1200, 40),
            new Termek(6, "Papírtörlő", Kategoria.Papir, 150, 60),
            new Termek(7, "Számítógép", Kategoria.Műszaki, 150000, 5),
            new Termek(8, "Tisztítószer", Kategoria.Vegyi, 800, 30),
            new Termek(9, "Kávé", Kategoria.Ital, 1200, 20),
            new Termek(10, "Zsebkendő", Kategoria.Papir, 200, 100)
        };
            listBox1.SelectionMode = SelectionMode.MultiExtended;
            FrissitTermekLista();
        }

        private void FrissitTermekLista()
        {
            listBox1.Items.Clear();
            foreach (var termek in termekLista)
            {
                listBox1.Items.Add(termek);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (UjTermekekHozzaAdasaForm addProductForm = new UjTermekekHozzaAdasaForm())
            {
                if (addProductForm.ShowDialog() == DialogResult.OK)
                {
                    Termek ujTermek = addProductForm.UjTermek;
                    termekLista.Add(ujTermek);
                    listBox1.Items.Add(ujTermek);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var kivalasztottTermekek = listBox1.SelectedItems;
            foreach (Termek termek in kivalasztottTermekek)
            {
                termekLista.Remove(termek);
            }
            FrissitTermekLista();
        }
    }
}
