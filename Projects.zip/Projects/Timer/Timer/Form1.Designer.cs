﻿namespace Timer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            timer1 = new System.Windows.Forms.Timer(components);
            label1 = new Label();
            label2 = new Label();
            button1 = new Button();
            progressBar1 = new ProgressBar();
            hScrollBar1 = new HScrollBar();
            label3 = new Label();
            SuspendLayout();
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 31.8000011F, FontStyle.Regular, GraphicsUnit.Point, 238);
            label1.Location = new Point(70, 31);
            label1.Name = "label1";
            label1.Size = new Size(674, 76);
            label1.TabIndex = 0;
            label1.Text = "RandomTickSpeed = 1000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F);
            label2.Location = new Point(378, 146);
            label2.Name = "label2";
            label2.Size = new Size(57, 41);
            label2.TabIndex = 1;
            label2.Text = "0.0";
            label2.Click += label2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F);
            button1.Location = new Point(469, 120);
            button1.Name = "button1";
            button1.Size = new Size(151, 67);
            button1.TabIndex = 2;
            button1.Text = "Start/stop";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // progressBar1
            // 
            progressBar1.ForeColor = Color.Salmon;
            progressBar1.Location = new Point(187, 231);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(463, 67);
            progressBar1.TabIndex = 3;
            // 
            // hScrollBar1
            // 
            hScrollBar1.Location = new Point(187, 328);
            hScrollBar1.Name = "hScrollBar1";
            hScrollBar1.Size = new Size(463, 50);
            hScrollBar1.TabIndex = 4;
            hScrollBar1.Value = 6;
            hScrollBar1.Scroll += hScrollBar1_Scroll;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(385, 390);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 5;
            label3.Text = "label3";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(hScrollBar1);
            Controls.Add(progressBar1);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private Label label1;
        private Label label2;
        private Button button1;
        private ProgressBar progressBar1;
        private HScrollBar hScrollBar1;
        private Label label3;
    }
}
