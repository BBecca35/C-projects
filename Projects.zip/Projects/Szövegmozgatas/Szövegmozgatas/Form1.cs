namespace Szövegmozgatas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Location = new Point(label1.Location.X - 100, label1.Location.Y);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Location = new Point(label1.Location.X + 100, label1.Location.Y);
        }
    }
}
