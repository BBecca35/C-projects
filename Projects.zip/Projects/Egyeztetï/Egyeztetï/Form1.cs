using System.Reflection;
using System.Security;
using System.Windows.Forms;

namespace Egyeztető
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool egyezikHetfo = checkBox1.Checked && checkBox10.Checked;
            bool egyezikKedd = checkBox2.Checked && checkBox9.Checked;
            bool egyezikSzerda = checkBox3.Checked && checkBox8.Checked;
            bool egyezikCsutortok = checkBox4.Checked && checkBox7.Checked;
            bool egyezikPentek = checkBox5.Checked && checkBox6.Checked;
            bool nemEgyezik = !egyezikHetfo && !egyezikKedd && !egyezikSzerda && !egyezikCsutortok && !egyezikPentek;

            if (nemEgyezik)
            {
                MessageBox.Show("Sajnos egyik félnél sem egyeznek a napok!");
            }
            else
            {
                List<string> napok = new List<string>();
                if (egyezikHetfo)
                {
                    napok.Add(checkBox1.Text);
                }
                if (egyezikKedd)
                {
                    napok.Add(checkBox2.Text);
                }
                if (egyezikSzerda)
                {
                    napok.Add(checkBox3.Text);
                }
                if (egyezikCsutortok)
                {
                    napok.Add(checkBox4.Text);
                }
                if (egyezikPentek)
                {
                    napok.Add(checkBox5.Text);
                }

                string uzenet = "";
                string utolsoNap = napok.Last();
                foreach (string nap in napok)
                {
                    if (nap == utolsoNap)
                    {
                        uzenet += nap + "!";
                    }
                    else
                    {
                        uzenet += nap + ", ";
                    }
                }
                MessageBox.Show("A következő napok egyeznek: " + uzenet);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
