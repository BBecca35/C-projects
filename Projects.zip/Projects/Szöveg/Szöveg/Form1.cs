namespace Szöveg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "Üdvözöllek, " + textBox1.Text;
            label2.Visible = true;
            int szuletesiEv = int.Parse(textBox2.Text);
            int szuletesiEv2 = Convert.ToInt32(textBox2.Text);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                label2.Text = "Üdvözöllek, " + textBox1.Text;
                label2.Visible = true;
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
