namespace Meghajtók
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DriveInfo[] meghajtok;
        private void Form1_Load(object sender, EventArgs e)
        {
            meghajtok = DriveInfo.GetDrives();
            listBox1.Items.AddRange(meghajtok);
            comboBox1.Items.AddRange(meghajtok);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String tipus = meghajtok[listBox1.SelectedIndex].
                DriveType.ToString();
            long teljesMeretGB = meghajtok[listBox1.SelectedIndex].TotalSize / 1024 / 1024 / 1024;

            label2.Text = "Típusa: " + tipus + ", mérete: " + teljesMeretGB + "GB";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String tipus = meghajtok[comboBox1.SelectedIndex].
                DriveType.ToString();
            long teljesMeretGB = meghajtok[comboBox1.SelectedIndex].TotalSize / 1024 / 1024 / 1024;

            label2.Text = "Típusa: " + tipus + ", mérete: " + teljesMeretGB + "GB";
        }
    }
}
