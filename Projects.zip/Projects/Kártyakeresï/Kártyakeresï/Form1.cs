using System.Globalization;

namespace Kártyakereső
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        enum Cards { 
            VII = 7,
            VIII = 8,
            IX = 9,
            X = 10,
            Alsó = 2,
            Felső = 3,
            Király = 4,
            Ász = 11
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int szam = Int32.Parse(textBox2.Text);
                bool kartyaLetezeik = Enum.IsDefined(typeof(Cards), textBox1.Text);
                bool kartyaSzam = Enum.IsDefined(typeof(Cards), szam);

                if (!kartyaLetezeik)
                {
                    MessageBox.Show("A kártyalap nem létezik!");
                }
                else if (!kartyaSzam)
                {

                    MessageBox.Show("Ezzel az értékkel kártya nem létezik!");
                }
                else
                {

                    MessageBox.Show("A(z) " + textBox1.Text + "-" + textBox2.Text + " nevű kártya létezik!");
                }
            }
            catch (FormatException exp) {
                MessageBox.Show("Hiba: A számformátum nem megfelelő!");
            }   
        }
    }
}
