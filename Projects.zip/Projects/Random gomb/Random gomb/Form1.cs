namespace Random_gomb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random v�letlen = new Random();
            int x = v�letlen.Next(0, this.Size.Width - button1.Width);
            int y = v�letlen.Next(0, this.Size.Height - button1.Height);
            button1.Location = new Point(x, y);
        }

        private void Form1_MouseEnter(object sender, EventArgs e)
        {
            Random v�letlen = new Random();
            int x = v�letlen.Next(0, this.Size.Width - button1.Width);
            int y = v�letlen.Next(0, this.Size.Height - button1.Height);
            button1.Location = new Point(x, y);
        }

        private void Form1_MouseHover(object sender, EventArgs e)
        {
            Random v�letlen = new Random();
            int x = v�letlen.Next(0, this.Size.Width - button1.Width);
            int y = v�letlen.Next(0, this.Size.Height - button1.Height);
            button1.Location = new Point(x, y);
        }
    }
}
