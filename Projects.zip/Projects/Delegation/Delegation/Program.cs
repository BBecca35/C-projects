﻿// See https://aka.ms/new-console-template for more information
internal class Progam { 

    public delegate void ZeneDelegalt(string zene_cime);

    public static void ThreeDaysGrace(string zene_cime) {
        Console.WriteLine("A Three Days Grace nevű bandától hallgatom a(z) "+ zene_cime + " című zenét.");
    }

    public static void ThousandFootKrutch(string zene_cime)
    {
        Console.WriteLine("A Thousand Foot Krutch nevű bandától hallgatom a(z) " + zene_cime + " című zenét.");
    }
    private static void Main(string[] arg) {
        Console.WriteLine("Zenehallgatás:");
        ZeneDelegalt lejatszo;
        lejatszo = ThreeDaysGrace;
        lejatszo("Never Too Late");
        lejatszo = ThousandFootKrutch;
        lejatszo("Move");
        Console.WriteLine("A delegált objektumra több metódus is mutathat");
        lejatszo = ThreeDaysGrace;
        lejatszo += ThousandFootKrutch;
        lejatszo("Zenét hallgatok");
        Console.ReadKey();
    }

}


//Delegáció = függvény pointer