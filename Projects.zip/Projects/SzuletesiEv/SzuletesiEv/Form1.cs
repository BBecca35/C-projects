namespace SzuletesiEv
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userInput = textBox2.Text;
            DateTime parsedDate = new DateTime(2024, 1, 1);
            DateTime today = DateTime.Now;
            int yearToday = today.Year;
            string format = "yyyy-MM-dd";
            bool isValidDate = DateTime.TryParseExact(userInput, format,
            System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None,
            out parsedDate);
            if (isValidDate)
            {
                int year = parsedDate.Year;
                int eletKor = yearToday - year;
                if (eletKor >= 18)
                {
                    label2.Text = "�dv�z�llek, " + textBox2.Text + "! Nagykor� vagy.";
                    label2.Visible = true;
                }
                else
                {
                    label2.Text = "�dv�z�llek, " + textBox2.Text + "! Nem vagy nagykor�.";
                    label2.Visible = true;
                }
            }
            else
            {
                label2.Text = "A d�tum form�tuma nem helyes!";
                label2.Visible = true;
            }



        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox1.Text); ;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = !string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text);
        }
    }
}
