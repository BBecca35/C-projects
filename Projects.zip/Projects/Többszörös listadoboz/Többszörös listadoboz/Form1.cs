namespace Többszörös_listadoboz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Paraméter átadás módjai: érték szerint, referencia szerint

        private void fuggveny(in int parameter, out int p2, ref int p3) {
            p2 = 0;
            p3 = 0;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            foreach (var item in listBox1.SelectedIndices)
            {
                label2.Text += item.ToString();
            }

            */
            /*
            foreach (var item2 in listBox1.SelectedIndices)
            {
                label3.Text += listBox1.SelectedItems[listBox1.SelectedIndex];
            }
            */
            //törlés során mindig visszafele kell törölni
            label2.Text = "Elemek: " + string.Join(", " , listBox1.SelectedIndices.Cast<int>());
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
