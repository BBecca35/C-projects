﻿// See https://aka.ms/new-console-template for more information
internal class Program {

    public delegate void Muvelet(int szam1, int szam2);
    public static void Osszeadas(int szam1, int szam2) {
        Console.WriteLine("A két szám összege: " + szam1+szam2);
    }

    public static void Kivonas(int szam1, int szam2)
    {
        Console.WriteLine("A két szám összege: " + (szam1-szam2));
    }

    public static void Main(string[] args) {
        Console.WriteLine("Műveletek");
        Muvelet muveletek;
        muveletek = Osszeadas;

    
    }

}
