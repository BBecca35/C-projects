﻿namespace Jelölőnégyzetek
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            label1 = new Label();
            button1 = new Button();
            checkBox2 = new CheckBox();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(16, 49);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(175, 26);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Elfogadom az ÁFSZ-t!";
            checkBox1.UseCompatibleTextRendering = true;
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(235, 28);
            label1.TabIndex = 1;
            label1.Text = "Fogadd el a szabályzatot!";
            label1.Click += label1_Click;
            // 
            // button1
            // 
            button1.Enabled = false;
            button1.Location = new Point(150, 129);
            button1.Name = "button1";
            button1.Size = new Size(130, 33);
            button1.TabIndex = 2;
            button1.Text = "Megrendelés";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(16, 72);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(174, 24);
            checkBox2.TabIndex = 3;
            checkBox2.Text = "Feliratkozás hírlevélre";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(432, 273);
            Controls.Add(checkBox2);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(checkBox1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Megrendelés";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private Label label1;
        private Button button1;
        private CheckBox checkBox2;
    }
}
