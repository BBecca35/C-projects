﻿namespace Teszt
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gomb = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // gomb
            // 
            gomb.BackColor = Color.Fuchsia;
            gomb.Font = new Font("Times New Roman", 18F);
            gomb.Location = new Point(74, 142);
            gomb.Name = "gomb";
            gomb.Size = new Size(245, 72);
            gomb.TabIndex = 0;
            gomb.Text = "Kattints ide!";
            gomb.UseVisualStyleBackColor = false;
            gomb.Click += gomb_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Pristina", 28F);
            label1.Location = new Point(57, 67);
            label1.Name = "label1";
            label1.Size = new Size(262, 61);
            label1.TabIndex = 1;
            label1.Text = "Szevasz bástya!";
            label1.Visible = false;
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(382, 253);
            Controls.Add(label1);
            Controls.Add(gomb);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Köszöntés";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button gomb;
        private Label label1;
    }
}
