using static System.Windows.Forms.DataFormats;

namespace Szokoevek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userInput = textBox1.Text;
            DateTime parsedDate = new DateTime(2024, 1, 1);
            string format = "yyyy-MM-dd";
            bool isValidDate = DateTime.TryParseExact(userInput, format,
            System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None,
            out parsedDate);
            if (isValidDate) { 
                int year = parsedDate.Year;
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
                {
                    label2.Text = "Ez az �v sz�k��v";
                    label2.Visible = true;
                }
                else {
                    label2.Text = "Ez az �v nem sz�k��v";
                    label2.Visible = true;
                }
            }
            else
            {
                label2.Text = "A d�tum form�tuma nem helyes!";
                label2.Visible = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
