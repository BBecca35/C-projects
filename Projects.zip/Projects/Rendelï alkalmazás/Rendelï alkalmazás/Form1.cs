using System.Reflection;
using Rendelő_alkalmazás.Properties;

namespace Rendelő_alkalmazás
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void termek_kivalasztase(object sender, EventArgs e)
        {

        }

        private void radioGomb_kivalasztas(object sender, EventArgs e)
        {
            String? nem = null;
            String? termek_szine = null;
            String? felirat_szine = null;
            String? fizetesi_mod = null;
            if (nem != null &&
                termek_szine != null &&
                felirat_szine != null &&
                fizetesi_mod != null)
            {
                if (radioButton3.Checked)
                {
                    pictureBox1.Image = Resources.paypal2;
                }
                if (radioButton4.Checked)
                {
                    pictureBox1.Image = Resources.Credit_cards;
                }
                if (radioButton5.Checked)
                {
                    pictureBox1.Image = Resources.Credit_cards;
                }
                label4.Text = "Még nincs kiválasztva a tulajdonság!";
            }
            else
            {
                label1.Text = "Még nincs kiválasztva a tulajdonság!";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
