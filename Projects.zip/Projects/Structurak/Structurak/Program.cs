﻿// See https://aka.ms/new-console-template for more information
using static System.Net.Mime.MediaTypeNames;
namespace Structurak
{
    internal static class Program
    {

        struct Kerekpar
        {
            private int kerekMeret;
            private int ar;
            public Kerekpar(int kerekMeret, int ar)
            {
                this.kerekMeret = kerekMeret;
                this.ar = ar;
            }

            public int KerekMeret
            {
                get
                {
                    return kerekMeret;
                }
                set
                {
                    if (value > 0) kerekMeret = value;
                }
            }

            public int Ar
            {
                get
                {
                    return ar;
                }
                set
                {
                    if (value > 0) ar = value;
                }
            }

            public override string ToString()
            {
                return "Kerékméret " + kerekMeret;
            }
        }
        static void Main()
        {
            Kerekpar elsokerekpar = new Kerekpar(26, 380000);
            elsokerekpar.KerekMeret = 28;
            Console.WriteLine(elsokerekpar.KerekMeret);
            Console.WriteLine(elsokerekpar.Ar);
        }
    }
}
