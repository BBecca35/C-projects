namespace Timer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = !timer1.Enabled;
            //timer1.Start();
        }

        //double ido = 0.0;
        int ido2 = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value + 10 <= progressBar1.Maximum)
            {
                progressBar1.Value += 10;
            }

            /*
            //ido += 0.1;
            ido2++;
            //ido = Math.Round(ido, 2);
            label2.Text = ido2.ToString();
            */
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = hScrollBar1.Value.ToString();
            label3.Font.SizeInPoints = hScrollBar1.Value;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
