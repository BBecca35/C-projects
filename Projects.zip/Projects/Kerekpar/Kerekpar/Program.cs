namespace Kerekpar
{
    internal static class Program
    {

        struct Kerekpar {
            private int kerekMeret;
            public Kerekpar(int kerekMeret) { 
                this.kerekMeret = kerekMeret;
            }
            public int KerekMeret {
                get {
                    return kerekMeret;    
                }
                set {
                    if(value > 0) kerekMeret = value;
                }
            }
            public override string ToString()
            {
                return "Ker�km�ret " + kerekMeret; 
            }
        }


        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Kerekpar elsokerekpar = new Kerekpar(26);
            elsokerekpar.KerekMeret = 28;
            Console.WriteLine(elsokerekpar.KerekMeret);

            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}