namespace ListView
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            //ListView listView1 = new ListView();
            //listView1.Bounds = new Rectangle(new Point(10, 10), new Size(300, 200));
            listView1.Dock = DockStyle.Fill;

            // Set the view to show details.
            listView1.View = View.Details;
            // Allow the user to edit item text.
            listView1.LabelEdit = true;
            // Allow the user to rearrange columns.
            listView1.AllowColumnReorder = true;
            // Display check boxes.
            listView1.CheckBoxes = false;
            // Select the item and subitems when selection is made.
            listView1.FullRowSelect = true;
           // Display grid lines.
            listView1.GridLines = false;
            // Sort the items in the list in ascending order.
            listView1.Sorting = SortOrder.Ascending;

            //Mapp�k lek�rdez�se, bepakol�s a listview-ba:

            DirectoryInfo gy�k�rmappa = new DirectoryInfo(@"C:\");
            foreach (DirectoryInfo mappa in gy�k�rmappa.GetDirectories())
            {
                ListViewItem item = new ListViewItem(mappa.Name, 0);
                item.SubItems.Add(mappa.LastWriteTime.ToShortDateString());
                item.SubItems.Add("mappa");
                listView1.Items.Add(item);
            }

            //F�jlok lek�rdez�se, bepakol�s
            foreach (FileInfo f�jl in gy�k�rmappa.GetFiles())
            {
                ListViewItem item = new ListViewItem(f�jl.Name, 1);
                item.SubItems.Add(f�jl.LastWriteTime.ToShortDateString());
                item.SubItems.Add("dokumentum");
                listView1.Items.Add(item);
            }
            // Create columns for the items and subitems.
            // Width of -2 indicates auto-size.
            listView1.Columns.Add("N�v", -2, HorizontalAlignment.Left);
            listView1.Columns.Add("M�dos�t�s ideje", -2, HorizontalAlignment.Left);
            listView1.Columns.Add("T�pus", -2, HorizontalAlignment.Left);


            // Create two ImageList objects.
            ImageList imageListSmall = new ImageList();
            ImageList imageListLarge = new ImageList();

            // Initialize the ImageList objects with bitmaps.
            imageListSmall.Images.Add(Properties.Resources.folder);
            imageListSmall.Images.Add(Properties.Resources.document);
            imageListLarge.Images.Add(Properties.Resources.folder);
            imageListLarge.Images.Add(Properties.Resources.document);


            //Assign the ImageList objects to the ListView.
            listView1.LargeImageList = imageListLarge;
            listView1.SmallImageList = imageListSmall;

            // Add the ListView to the control collection.
            //this.Controls.Add(listView1);
        }
        
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
